<?php
/**
 *		Footer Sidebar Template for BRIC
 *
 *
 */

//global $BricLoop;


dynamic_sidebar( 'footer-content' );
 