<?php
/**
 *		FOOTER TEMPLATE for BRIC
 *
 *
 */
?>

<footer class="site-footer container-fluid pl-0 pr-0" itemscope itemtype="http://schema.org/WPFooter">
		<?php 
		
			/**
			 *		Bric Header
			 *
			 *		'' - 10
			 */
			
			do_action( 'bric_footer' );
		
		?>
</footer>
<?php

wp_footer();

?>
</body>
</html>