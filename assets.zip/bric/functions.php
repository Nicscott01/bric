<?php
/**
 *		Theme: Bric
 *		@author: Nic Scott
 *		@date September 2017
 *
 *
 *		Theme for basic small-business brochure-ware websites.
 *
 *
 */
define( 'PATH_NODE', '/home/creare2/webapps/node/bin' );
define( 'PATH_SASS', '/home/creare2/webapps/sass/bin' );
define( 'GEM_HOME', '/home/creare2/webapps/sass/gems' );
define( 'RUBYLIB', '/home/creare2/webapps/sass/lib' );	

include get_template_directory().'/inc/init.php';

